const express=require("express")
const router=express.Router()

const { register, validateRegister } = require("../controllers/register_api.js")
const { login, validateLogin } = require("../controllers/login_api.js")
const addTask=require("../controllers/task_controller.js")
const getTasks=require("../controllers/get_task.js")
const updateTaskStatus = require('../controllers/update_task_status_controller.js');
const deleteTask = require('../controllers/delete_task_controller.js');
const authenticateToken = require('../controllers/jwt_auth.js');



router.post('/register', validateRegister, register);
router.post('/login', validateLogin, login);
router.post('/tasks', addTask);
router.get('/tasks/:user_id', getTasks);
router.put('/tasks/:task_id', updateTaskStatus);
router.delete('/tasks/:task_id', deleteTask);

router.get('/protected', authenticateToken, (req, res) => {
    res.send('This is a protected route.');
});

router.get('/api/test', (req, res) => {
    res.send('API is working');
});

module.exports = router;