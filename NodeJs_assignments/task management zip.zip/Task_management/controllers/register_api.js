const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const connection = require("../mysql/mysql.js");
const handleError = require("./error_handler.js");

const validateRegister = [
    body('UserID').notEmpty().withMessage('UserID is required'),
    body('FirstName').notEmpty().withMessage('First name is required'),
    body('LastName').notEmpty().withMessage('Last name is required'),
    body('Email').isEmail().withMessage('Email must be a valid email address'),
    body('Password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters long'),
    body('Address').optional().isString().withMessage('Address must be a string')
];

const register = async (req, res) => {
    const { UserID, FirstName, LastName, Email, Password, Address } = req.body;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const hashedPassword = await bcrypt.hash(Password, 10);

        const query = `INSERT INTO users (UserID, FirstName, LastName, Email, Password, Address, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, NOW())`;
        connection.query(query, [UserID, FirstName, LastName, Email, hashedPassword, Address], (err, results) => {
            if (err) {
                return handleError(err, res);
            }

            res.status(201).send('User registered successfully.');
        });
    } catch (err) {
        handleError(err, res);
    }
};

module.exports = { register, validateRegister };
